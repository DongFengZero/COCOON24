from __future__ import print_function

from collections import defaultdict
import collections
from datetime import datetime
import os
import json
import logging

import numpy as np
import pygraphviz as pgv

import torch
from torch.autograd import Variable

from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw 


try:
    import scipy.misc
    import imageio	
    from skimage.transform import resize
    imread = imageio.imread
    imresize = resize
    imsave = imwrite = imageio.imsave
except:
    from skimage import transform
    imread = cv2.imread
    imresize = transform.resize
    imsave = imwrite = cv2.imwrite


##########################
# Network visualization
##########################

def dag_prev_convert(dag,node_num):
    prev_node_id = []
    prev_node_op = []
    for node_id in range(node_num + 3):
        prev_node_id.append([])
        prev_node_op.append([])

    for node_id in range(-2, node_num, 1):
        nodes = dag[node_id]
        for next_node in nodes:
            prev_node_id[next_node.id + 2].append(node_id)
            prev_node_op[next_node.id + 2].append(next_node.name)

    return prev_node_id, prev_node_op

def judge_legal(dag, node_id, node_num, prev_node):
    next_id = node_id
    stack = collections.deque()
    stack.append(next_id)
    illegal = []
    if len(prev_node[node_id + 2]) == 0 and node_id > 0:
        return False
    while len(stack) != 0:
        next_id = stack.popleft()
        if next_id in illegal:
            continue
        if next_id == node_num:
            return True
        if len(dag[next_id]) == 0:
            illegal.append(next_id)
        for i in range(len(dag[next_id])):
            stack.append(dag[next_id][i].id)
    return False
def add_node(graph, node_id, label, shape='box', style='filled'):
    if label.startswith('x'):
        color = 'white'
    elif label.startswith('h') or label == 'max_pool':
        color = 'skyblue'
    elif label == 'tanh' or label == 'avg_pool':
        color = 'yellow'
    elif label == 'ReLU' or label == 'Add':
        color = 'pink'
    elif label == 'conv3':
        color = 'orange'
    elif label == 'sigmoid' or label == 'conv5':
        color = 'greenyellow'
    elif label == 'avg' or label == 'Softmax':
        color = 'seagreen3'
    else:
        color = 'white'

    if not any(label.startswith(word) for word in  ['x', 'avg', 'h']):
        label = f"{label}\n({node_id})"

    graph.add_node(
            node_id, label=label, color='black', fillcolor=color,
            shape=shape, style=style,
    )

def draw_network(dag, path, net_type, num_number):
    makedirs(os.path.dirname(path))
    graph = pgv.AGraph(directed=True, strict=False,
                       fontname='Helvetica', arrowtype='open'
                       ,overlap=False, splines='true') # not work?
    prev_id, prev_op = dag_prev_convert(dag,num_number)

    if net_type == 'rnn':
        checked_ids = [-2, -1, 0]
        if -1 in dag:
            add_node(graph, -1, 'x[t]')
        if -2 in dag:
            add_node(graph, -2, 'h[t-1]')

        add_node(graph, 0, dag[-1][0].name)

        for idx in range(num_number+1):
            if len(dag[idx])==0 and idx!=num_number:
                continue
            if len(prev_id[idx+2])==0:
                continue
            if not judge_legal(dag, idx, num_number):
                continue
            if idx not in checked_ids:
                if idx!=num_number:
                    add_node(graph, idx, prev_op[idx+2][0])
                    checked_ids.append(idx)
                else:
                    add_node(graph, idx, "avg")
                    checked_ids.append(idx)
            for id in prev_id[idx+2]:
                if id!=-1 and id!=-2:
                    if id not in checked_ids or len(prev_id[id+2])==0:
                        continue
                graph.add_edge(id, idx)

        add_node(graph, num_number + 1, 'h[t]')
        graph.add_edge(num_number, num_number + 1)

    if net_type == 'cnn':
        print(dag)
        checked_ids = []
        if judge_legal(dag, -2, num_number, prev_id):
            checked_ids.append(-2)
        if judge_legal(dag, -1, num_number, prev_id):
            checked_ids.append(-1)
        if -1 in dag and judge_legal(dag, -1, num_number, prev_id):
            add_node(graph, -1, 'layer_i')
        if -2 in dag and judge_legal(dag, -2, num_number, prev_id):
            add_node(graph, -2, 'layer_(i-1)')

        for idx in range(num_number+1):
            if len(dag[idx])==0 and idx!=num_number:
                continue
            if not judge_legal(dag, idx, num_number, prev_id):
                continue
            if idx not in checked_ids:
                if idx!=num_number:
                    add_node(graph, idx, "Add")
                    checked_ids.append(idx)
                else:
                    add_node(graph, idx, "avg")
                    checked_ids.append(idx)

            num = 0
            for id in prev_id[idx+2]:
                # if not judge_legal(dag,id,num_number) or len(prev_id[id+2])==0:
                #     continue
                if idx != num_number:
                    if prev_op[idx+2][num]=="avg_pool":
                        graph.add_edge(id, idx, prev_op[idx + 2][num],color="green")
                    elif prev_op[idx+2][num]=="max_pool":
                        graph.add_edge(id, idx, prev_op[idx + 2][num],color="blue")
                    elif prev_op[idx+2][num]=="conv3":
                        graph.add_edge(id, idx, prev_op[idx + 2][num],color="pink")
                    elif prev_op[idx + 2][num] == "conv5":
                        graph.add_edge(id, idx, prev_op[idx + 2][num],color="red")
                    num += 1
                else:
                    graph.add_edge(id, idx)

    # for idx in dag:
    #     for node in dag[idx]:
    #         if node.id not in checked_ids:
    #             add_node(graph, node.id, node.name)
    #             checked_ids.append(node.id)
    #         graph.add_edge(idx, node.id)

    graph.layout(prog='dot')
    graph.draw(path)

def make_gif(paths, gif_path, max_frame=50, prefix=""):
    import imageio

    paths.sort()

    skip_frame = len(paths) // max_frame
    paths = paths[::skip_frame]

    images = [imageio.imread(path) for path in paths]
    max_h, max_w, max_c = np.max(
            np.array([image.shape for image in images]), 0)

    for idx, image in enumerate(images):
        h, w, c = image.shape
        blank = np.ones([max_h, max_w, max_c], dtype=np.uint8) * 255

        pivot_h, pivot_w = (max_h-h)//2, (max_w-w)//2
        blank[pivot_h:pivot_h+h,pivot_w:pivot_w+w,:c] = image

        images[idx] = blank

    try:
        images = [Image.fromarray(image) for image in images]
        draws = [ImageDraw.Draw(image) for image in images]
        font = ImageFont.truetype("assets/arial.ttf", 30)

        steps = [int(os.path.basename(path).rsplit('.', 1)[0].split('-')[1]) for path in paths]
        for step, draw in zip(steps, draws):
            draw.text((max_h//20, max_h//20),
                      f"{prefix}step: {format(step, ',d')}", (0, 0, 0), font=font)
    except IndexError:
        pass

    imageio.mimsave(gif_path, [np.array(img) for img in images], duration=0.5)


##########################
# Torch
##########################

def detach(h):
    if type(h) == Variable:
        return Variable(h.data)
    else:
        return tuple(detach(v) for v in h)

def get_variable(inputs, cuda=False, **kwargs):
    if type(inputs) in [list, np.ndarray]:
        inputs = torch.Tensor(inputs)
    if cuda:
        out = Variable(inputs.cuda(), **kwargs)
    else:
        out = Variable(inputs, **kwargs)
    return out

def update_lr(optimizer, lr):
    for param_group in optimizer.param_groups:
        param_group['lr'] = lr

def batchify(data, bsz, use_cuda):
    # code from https://github.com/pytorch/examples/blob/master/word_language_model/main.py 
    nbatch = data.size(0) // bsz
    data = data.narrow(0, 0, nbatch * bsz)
    data = data.view(bsz, -1).t().contiguous()
    if use_cuda:
        data = data.cuda()
    return data


##########################
# ETC
##########################

Node = collections.namedtuple('Node', ['id', 'name'])


class keydefaultdict(defaultdict):
    def __missing__(self, key):
        if self.default_factory is None:
            raise KeyError(key)
        else:
            ret = self[key] = self.default_factory(key)
            return ret


def to_item(x):
    """Converts x, possibly scalar and possibly tensor, to a Python scalar."""
    if isinstance(x, (float, int)):
        return x

    if float(torch.__version__[0:3]) < 0.4:
        assert (x.dim() == 1) and (len(x) == 1)
        return x[0]

    return x.item()


def get_logger(name=__file__, level=logging.INFO):
    logger = logging.getLogger(name)

    if getattr(logger, '_init_done__', None):
        logger.setLevel(level)
        return logger

    logger._init_done__ = True
    logger.propagate = False
    logger.setLevel(level)

    formatter = logging.Formatter("%(asctime)s:%(levelname)s::%(message)s")
    handler = logging.StreamHandler()
    handler.setFormatter(formatter)
    handler.setLevel(0)

    del logger.handlers[:]
    logger.addHandler(handler)

    return logger


logger = get_logger()


def prepare_dirs(args):
    """Sets the directories for the model, and creates those directories.

    Args:
        args: Parsed from `argparse` in the `config` module.
    """
    if args.load_path:
        if args.load_path.startswith(args.log_dir):
            args.model_dir = args.load_path
        else:
            if args.load_path.startswith(args.dataset):
                args.model_name = args.load_path
            else:
                args.model_name = "{}_{}".format(args.dataset, args.load_path)
    else:
        args.model_name = "{}_{}".format(args.dataset, get_time())

    if not hasattr(args, 'model_dir'):
        args.model_dir = os.path.join(args.log_dir, args.model_name)
    args.data_path = os.path.join(args.data_dir, args.dataset)

    for path in [args.log_dir, args.data_dir, args.model_dir]:
        if not os.path.exists(path):
            makedirs(path)

def get_time():
    return datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

def save_args(args):
    param_path = os.path.join(args.model_dir, "params.json")

    logger.info("[*] MODEL dir: %s" % args.model_dir)
    logger.info("[*] PARAM path: %s" % param_path)

    with open(param_path, 'w') as fp:
        json.dump(args.__dict__, fp, indent=4, sort_keys=True)

def save_dag(args, dag, name):
    save_path = os.path.join(args.model_dir, name)
    logger.info("[*] Save dag : {}".format(save_path))
    json.dump(dag, open(save_path, 'w'))

def load_dag(args):
    load_path = os.path.join(args.dag_path)
    logger.info("[*] Load dag : {}".format(load_path))
    with open(load_path) as f:
        dag = json.load(f)
    dag = {int(k): [Node(el[0], el[1]) for el in v] for k, v in dag.items()}
    save_dag(args, dag, "dag.json")
    draw_network(dag, os.path.join(args.model_dir, "dag.png"))
    return dag          
  
def makedirs(path):
    if not os.path.exists(path):
        logger.info("[*] Make directories : {}".format(path))
        os.makedirs(path)

def remove_file(path):
    if os.path.exists(path):
        logger.info("[*] Removed: {}".format(path))
        os.remove(path)

def backup_file(path):
    root, ext = os.path.splitext(path)
    new_path = "{}.backup_{}{}".format(root, get_time(), ext)

    os.rename(path, new_path)
    logger.info("[*] {} has backup: {}".format(path, new_path))
