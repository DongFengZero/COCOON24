import torch
import torch.nn as nn
import torch.nn.functional as F
import copy
import math
import utils

from tensorboardX import SummaryWriter


# class InitLayer(nn.Module):
#     """The initial layer of the network: one convolution layer followed by one
#         batch normalization layer
#     """
#
#     def __init__(self, in_channels, out_channels, kernel_size, trs=False, bias=False):
#         super(InitLayer, self).__init__()
#         padding = (kernel_size - 1) // 2  # keep the same size
#         self.input_conv = nn.Sequential(
#             nn.Conv2d(in_channels,
#                       out_channels,
#                       kernel_size=kernel_size,
#                       padding=padding,
#                       bias=bias),
#             nn.BatchNorm2d(out_channels,
#                            track_running_stats=trs))
#
#     def forward(self, x):
#         out = self.input_conv(x)
#         return out
#
#
#
# class IdentityBranch(nn.Module):
#     """The identity branch.
#     """
#
#     def __init__(self):
#         super(IdentityBranch, self).__init__()
#
#     def forward(self, x):
#         return x


class SeparableConv(nn.Module):
    """Implement the depthwise-separable convolution cell.
    """

    def __init__(self, in_channels, out_channels, kernel_size, bias=True):
        super(SeparableConv, self).__init__()

        self.inp_conv1 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False),
            nn.BatchNorm2d(out_channels, track_running_stats=False, affine=False),
            nn.ReLU())

        padding = (kernel_size - 1) // 2  # keep the size unchanged
        self.depthwise = nn.Conv2d(in_channels, in_channels,
                                   kernel_size=kernel_size,
                                   padding=padding,
                                   groups=in_channels,
                                   bias=bias)
        self.pointwise = nn.Conv2d(in_channels, out_channels,
                                   kernel_size=1, bias=bias)
        self.relu_bn = nn.Sequential(
            nn.BatchNorm2d(out_channels, track_running_stats=False),
            nn.ReLU())

    def forward(self, out1):
        """
        Args:
            x: [N, C_in, H, W]

        Return:
            out: [N, C_out, H, W]
        """
        # out1 = self.inp_conv1(out1)
        out = self.pointwise(self.depthwise(out1))
        out = out+out1
        out = self.relu_bn(out)
        return out

class PoolBranch(nn.Module):
    '''
    https://github.com/melodyguan/enas/blob/master/src/cifar10/general_child.py#L546
    '''
    def __init__(self, in_planes, out_planes, avg_or_max):
        super(PoolBranch, self).__init__()

        self.in_planes = in_planes
        self.out_planes = out_planes
        self.avg_or_max = avg_or_max

        self.conv1 = nn.Sequential(
            nn.Conv2d(in_planes, out_planes, kernel_size=1, bias=False),
            nn.BatchNorm2d(out_planes, track_running_stats=False, affine=False),
            nn.ReLU())

        if avg_or_max == 'avg':
            self.pool = torch.nn.AvgPool2d(kernel_size=3, stride=1, padding=1)
        elif avg_or_max == 'max':
            self.pool = torch.nn.MaxPool2d(kernel_size=3, stride=1, padding=1)
        else:
            raise ValueError("Unknown pool {}".format(avg_or_max))

    def forward(self, out):
        # out = self.conv1(out)
        out = self.pool(out)
        return out

class ENASCell(nn.Module):
    """Implement one ENAS cell (or node), each cell can have 5 different operations:
       avg_pool, max_pool, 3*3 conv, 5*5 conv, identity.
    """

    def __init__(self, in_channels, out_channels):
        super(ENASCell, self).__init__()

        in_c, out_c = in_channels, out_channels
        self.choices = nn.ModuleDict({
            'conv3': SeparableConv(in_c, out_c, 3),
            'conv5': SeparableConv(in_c, out_c, 5),
            'avg_pool': PoolBranch(in_c, out_c, 'avg'),
            'max_pool': PoolBranch(in_c, out_c, 'max')
            # 'avg_pool': nn.AvgPool2d(3, padding=1, stride=1),
            # 'max_pool': nn.MaxPool2d(3, padding=1, stride=1)
        })

        self.choices1 = nn.ModuleDict({
            'conv3': SeparableConv(in_c, out_c, 3),
            'conv5': SeparableConv(in_c, out_c, 5),
            'avg_pool': PoolBranch(in_c, out_c, 'avg'),
            'max_pool': PoolBranch(in_c, out_c, 'max')
        })

    def forward(self, x, op, flag):
        """
        Args:
            x: input from previous cell.
            op: integer, indicate which operation to use.
        """
        if flag==0:
            out = {
                'conv3': lambda x: self.choices['conv3'](x),
                'conv5': lambda x: self.choices['conv5'](x),
                'avg_pool': lambda x: self.choices['avg_pool'](x),
                'max_pool': lambda x: self.choices['max_pool'](x)
            }[op](x)
        else:
            out = {
                'conv3': lambda x: self.choices1['conv3'](x),
                'conv5': lambda x: self.choices1['conv5'](x),
                'avg_pool': lambda x: self.choices1['avg_pool'](x),
                'max_pool': lambda x: self.choices1['max_pool'](x)
            }[op](x)

        return out

class CNN(nn.Module):

    def __init__(self, args, fixed=False):
        super(CNN, self).__init__()
        self.args = args
        self.node_num = args.num_blocks
        # self.out_channels = args.out_channels
        # self.out_channels2 = args.out_channels2
        self.out_filter = args.out_filter

        # build cells (nodes), node_num does NOT include two input nodes
        Cell = ENASCell
        self.global_max_pool = nn.MaxPool2d(kernel_size=2, stride=2)
        self.nodes = nn.ModuleList()
        self.prev_node_id = []
        self.prev_node_op = []
        self.stem_conv = []
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(64, track_running_stats=False, affine=False)).cuda())
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(128, track_running_stats=False, affine=False)).cuda())
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(256, track_running_stats=False, affine=False)).cuda())
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(256, 512, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(512, track_running_stats=False, affine=False)).cuda())
        self.classify = nn.Linear(2048, self.args.kind, bias=False)
        self.Softmax =nn.Softmax(dim=-1)

        for cell_id in range(2, self.node_num + 2):
            self.nodes.append(Cell(64, 64))
        for cell_id in range(2, self.node_num + 2):
            self.nodes.append(Cell(128, 128))
        for cell_id in range(2, self.node_num + 2):
            self.nodes.append(Cell(256, 256))
        for cell_id in range(2, self.node_num + 2):
            self.nodes.append(Cell(512, 512))

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_uniform_(m.weight, mode='fan_in', nonlinearity='relu')

    def dag_convert(self, dag):
        self.dag = dag
        self.prev_node_id = []
        self.prev_node_op = []
        for node_id in range(self.node_num+3):
            self.prev_node_id.append([])
            self.prev_node_op.append([])

        for node_id in range(-2,self.node_num-1,1):
            nodes = dag[node_id]
            for next_node in nodes:
                self.prev_node_id[next_node.id+2].append(node_id)
                self.prev_node_op[next_node.id+2].append(next_node.name)


    def forward(self, inputs, is_train=True):
        """Forward two inputs through one ENAS layer, the unused inputs are concatenated.

        Args:
            inputs: (h[i], h[i-1]),
            arc: list of integers, representing the architecture of the cell.
        """

        is_train = is_train and self.args.mode in ['train']
        x = inputs
        #self.dag_convert(dag)
        last_input = x
        last_input2 = x
        final = None
        for conv_id in range(4):
            last_input2 = self.stem_conv[conv_id](last_input2)
            last_input = self.stem_conv[conv_id](last_input)
            node_inps=[last_input2,last_input]
            node_use=[0,0]
            now_input = None
            #node_inps = []
            #node_inps.extend(self._celibrate_size(inputs))  # assure two inputs have same shape
            for i in range(self.node_num):
                out = None
                node_use.append(0)
                if len(self.prev_node_op[i+2])==0:
                    node_inps.append(None)
                    continue
                # the first operation
                # if i>=2:
                x_id, x_op = self.prev_node_id[i+2][0] , self.prev_node_op[i+2][0]
                x = node_inps[x_id+2]
                if x!=None:
                    node_use[x_id+2] += 1
                    x_out = self.nodes[conv_id*self.node_num+i](x, x_op, 0)

                if len(self.prev_node_op[i+2])==1:
                    if x != None:
                        now_input = x_out
                        node_inps.append(x_out)
                        continue
                    else:
                        node_inps.append(None)
                        continue

                # the second operation
                y_id, y_op = self.prev_node_id[i+2][1] , self.prev_node_op[i+2][1]
                y = node_inps[y_id+2]
                if y!=None:
                    node_use[y_id + 2] += 1
                    y_out = self.nodes[conv_id*self.node_num+i](y, y_op, 1)

                if x!=None and y!=None:
                    out = x_out + y_out
                elif x==None and y!=None:
                    out = y_out
                elif x!=None and y==None:
                    out = x_out
                else:
                    out = None
                # else:
                #     x_id, x_op = self.prev_node_id[i+2][0], self.prev_node_op[i+2][0]
                #     x = node_inps[x_id + 2]
                #     out = self.nodes[conv_id*self.node_num+i](x, x_op, 0)

                node_inps.append(out)

            # concatenate all outputs and project
            # NOTE: in the paper this is done for all unused nodes, here we make it sample
            for i in range(self.node_num+2):
                if node_inps[i]!=None and node_use[i]==0:
                    if now_input!=None:
                        now_input = (now_input+node_inps[i])/2
                    else:
                        now_input = node_inps[i]
            last_input2 = self.global_max_pool(last_input)
            last_input = self.global_max_pool(now_input)
            final = last_input

        final = final.view(final.shape[0], -1)
        final_output = self.classify(final)

        return final_output

    def _celibrate_size(self, inputs):
        """Because of the reduction cell, the second input might have half WH size
           and double depth size. This function is to make sure two inputs have the
           same W and H, and the depth equals to out_channels.
        """
        outs = []
        for i, inp in enumerate(inputs):
            if self._get_C(inp) != self.out_channels:
                outs.append(self.frs[i](inp))
            else:
                outs.append(inp)

        assert outs[0].shape == outs[1].shape
        return outs

    def _get_C(self, x):
        """Get channel size of a given feature map.
        """
        return x.shape[1]

    def _get_HW(self, x):
        """Get H and W of a given feature map.
        """
        return x.shape[-2], x.shape[-1]
    def init_hidden(self, batch_size):
        zeros = torch.zeros(batch_size, self.args.shared_hid)
        return utils.get_variable(zeros, self.args.cuda, requires_grad=False)


