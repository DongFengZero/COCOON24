"""A module with NAS controller-related code."""
import collections
import os

os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
import torch
import torch.nn.functional as F
import math
import utils
from utils import Node
import dgl
import GCN


def get_max_index(lst):
    if not isinstance(lst, list):
        lst = lst.tolist()
    return lst.index(max(lst))

def get_second_largest(lst):
    if not isinstance(lst,list):
        lst = lst.tolist()
    sorted_list = sorted(lst)
    second_largest = sorted_list[-2]

    return second_largest,lst.index(second_largest)

def judge_legal(dag, node_id, node_num, prev_node):
    next_id = node_id
    stack = collections.deque()
    stack.append(next_id)
    illegal = []
    if len(prev_node[node_id + 2]) == 0 and node_id >= 0:
        return False
    while len(stack) != 0:
        next_id = stack.popleft()
        if next_id in illegal:
            continue
        if next_id == node_num:
            return True
        if len(dag[next_id]) == 0:
            illegal.append(next_id)
        for i in range(len(dag[next_id])):
            stack.append(dag[next_id][i].id)
    return False

def dag_prev_convert(dag,node_num):
    prev_node_id = []
    prev_node_op = []
    for node_id in range(node_num + 3):
        prev_node_id.append([])
        prev_node_op.append([])

    for node_id in range(-2, node_num, 1):
        nodes = dag[node_id]
        for next_node in nodes:
            prev_node_id[next_node.id + 2].append(node_id)
            prev_node_op[next_node.id + 2].append(next_node.name)

    return prev_node_id, prev_node_op

def _construct_dags_rnn(_logits, _link_prob, func_names, num_blocks):

    dag = collections.defaultdict(list)
    # add first node
    dag[-1] = [Node(0, func_names[get_max_index(_logits[0])])]
    dag[-2] = [Node(0, func_names[get_max_index(_logits[0])])]

    legal_node = [-1,-2,0]

    # add following nodes
    for jdx, _node_prob in enumerate(_logits[1:]):
        prev_num = 0
        for idx in range(0, jdx+1):
            if idx not in legal_node:
                continue
            if _link_prob[jdx+1][idx] > 0.5:
                dag[idx].append(Node(jdx + 1, func_names[get_max_index(_node_prob)]))
                prev_num += 1
        if prev_num!=0:
            legal_node.append(jdx+1)

    # find leaf nodes
    for idx in range(num_blocks):
        if len(dag[idx]) == 0 and idx in legal_node:
            dag[idx] = [Node(num_blocks, 'avg')]

    last_node = Node(num_blocks + 1, 'h[t]')
    dag[num_blocks] = [last_node]


    return dag


def _construct_dags_cnn(_logits, _link_prob, func_names, num_blocks):

    dag = collections.defaultdict(list)

    _logits_t=[[],[]]
    for i in range(2):
        for j in range(4):
            _logits_t[i].append(sum(_logits[i][j*4:j*4+4]))

    # add following nodes
    for jdx, _node_prob in enumerate(_logits[2:]):
        idx = get_max_index(_link_prob[jdx + 2][:(jdx + 2)*(jdx + 2)])
        idx_1 = idx // (jdx + 2) - 2
        idx_2 = idx % (jdx + 2) - 2
        opid = get_max_index(_logits[jdx + 2][:])
        opid_1 = opid // len(func_names)
        opid_2 = opid % len(func_names)

        dag[idx_1].append(Node(jdx, func_names[opid_1]))
        if not(idx_2 == idx_1 and func_names[opid_1]==func_names[opid_2]):
            dag[idx_2].append(Node(jdx, func_names[opid_2]))

    last_node = Node(num_blocks, 'avg')
    dag[num_blocks - 1] = [last_node]
    prev_node, prev_op = dag_prev_convert(dag, num_blocks)

    fix_dag = collections.defaultdict(list)
    # add following nodes

    Flag = True

    for jdx, _node_prob in enumerate(_logits[2:]):
        idx = get_max_index(_link_prob[jdx + 2][:(jdx + 2) * (jdx + 2)])
        idx_1 = idx // (jdx + 2) - 2
        idx_2 = idx % (jdx + 2) - 2
        opid = get_max_index(_logits[jdx + 2][:])
        opid_1 = opid // len(func_names)
        opid_2 = opid % len(func_names)
        if judge_legal(dag,idx_1,num_blocks,prev_node) and judge_legal(dag,jdx,num_blocks,prev_node):
            fix_dag[idx_1].append(Node(jdx, func_names[opid_1]))
            if opid_1 < 2:
                Flag = False
        if judge_legal(dag, idx_2, num_blocks,prev_node) and judge_legal(dag, jdx, num_blocks,prev_node):
            if not (idx_2 == idx_1 and func_names[opid_1] == func_names[opid_2]):
                fix_dag[idx_2].append(Node(jdx, func_names[opid_2]))
                if opid_2 < 2:
                    Flag = False

    for idx in range(num_blocks):
        if len(fix_dag[idx]) == 0 and judge_legal(dag, idx, num_blocks,prev_node):
            fix_dag[idx] = [Node(num_blocks, 'avg')]

    # last_node = Node(num_blocks+1, 'softmax')
    # fix_dag[num_blocks] = [last_node]

    return fix_dag,Flag

class Controller(torch.nn.Module):
    """Based on
    https://github.com/pytorch/examples/blob/master/word_language_model/model.py

    TODO(brendan): RL controllers do not necessarily have much to do with
    language models.

    Base the controller RNN on the GRU from:
    https://github.com/ikostrikov/pytorch-a2c-ppo-acktr/blob/master/model.py
    """
    def __init__(self, args):
        torch.nn.Module.__init__(self)
        self.args = args
        self.func_names = []
        self._num_of_nodes = self.args.num_blocks
        if self.args.network_type == 'rnn':
            self.func_names = args.shared_rnn_activations
        elif self.args.network_type == 'cnn':
            self.func_names = args.shared_cnn_types

        self.num_of_features = len(self.func_names)

        if self.args.network_type=='rnn':
            temp1, temp2 = [0], [0]
            for i in range(self._num_of_nodes):
                for j in range(i + 1, self._num_of_nodes):
                    temp1.append(i)
                    temp2.append(j)
            self.graph = dgl.graph((temp1, temp2), num_nodes=self._num_of_nodes)
            self.embed = torch.nn.Embedding(self._num_of_nodes, self.num_of_features)
        if self.args.network_type=='cnn':
            temp1, temp2 = [0], [0]
            for i in range(self._num_of_nodes+2):
                for j in range(i + 1, self._num_of_nodes+2):
                    temp1.append(i)
                    temp2.append(j)
            self.graph = dgl.graph((temp1, temp2), num_nodes=self._num_of_nodes+2)
            self.embed = torch.nn.Embedding(self._num_of_nodes+2, self.num_of_features * self.num_of_features)
        self.graph.ndata['feat'] = self.embed.weight
        self.graph_neural_network = GCN.GCN(self.graph.ndata['feat'].shape[1],self.args.controller_hid,
                                            self.num_of_features,self._num_of_nodes,self.args.network_type)
        self.graph = self.graph.to(torch.device('cuda:0'))

        def _get_default_hidden(key):
            return utils.get_variable(
                torch.zeros(key, self.args.controller_hid),
                self.args.cuda,
                requires_grad=False)

        self.static_inputs = utils.keydefaultdict(_get_default_hidden)
        self.static_init_hidden = utils.keydefaultdict(self.init_hidden)

    def forward(self):
        _logit,_link_probs = self.graph_neural_network(self.graph, self.graph.ndata['feat'])
        return _logit,_link_probs

    def sample(self, batch_size=1, with_details=False, save_dir=None):
        """Samples a set of `args.num_blocks` many computational nodes from the
        controller, where each node is made up of an activation function, and
        each node except the last also includes a previous node.
        """
        if batch_size < 1:
            raise Exception(f'Wrong batch_size: {batch_size} < 1')

        # [B, L, H]
        entropies = []
        log_probs = []
        entropies1 = []
        log_probs1 = []

        model = self.graph_neural_network
        model.cuda()
        model.train()
        logits,_link_probs = self.forward()

        probs = F.softmax(logits, dim=-1)
        log_prob = F.log_softmax(logits, dim=-1)

        if self.args.network_type == 'rnn':
            _link_probs1 = _link_probs.reshape(_link_probs.shape[0]*_link_probs.shape[1],1).cuda()
            _link_probs2 = torch.ones(_link_probs.shape[0]*_link_probs.shape[1],1).cuda()-_link_probs1
            _link_probs1 = torch.stack((_link_probs1,_link_probs2),dim=1).squeeze()

            probs1 = F.softmax(_link_probs1, dim=-1)
            log_prob1 = F.log_softmax(_link_probs1, dim=-1)
            _link_probs = probs1.reshape(self._num_of_nodes,self._num_of_nodes-1,2)[:,:,0]
        if self.args.network_type == 'cnn':
            probs1 = F.softmax(_link_probs, dim=-1)
            log_prob1 = F.log_softmax(_link_probs, dim=-1)

        # TODO(brendan): .mean() for entropy?
        entropy = -(log_prob * probs).sum(1, keepdim=False)
        entropy1 = -(log_prob1 * probs1).sum(1, keepdim=False)

        action = probs.multinomial(num_samples=1).data
        selected_log_prob = log_prob.gather(
            1, utils.get_variable(action, requires_grad=False))

        action1 = probs1.multinomial(num_samples=1).data
        selected_log_prob1 = log_prob1.gather(
            1, utils.get_variable(action1, requires_grad=False))

        # TODO(brendan): why the [:, 0] here? Should it be .squeeze(), or
        # .view()? Same below with `action`.
        entropies.append(entropy)
        log_probs.append(selected_log_prob[:, 0])

        entropies1.append(entropy1)
        log_probs1.append(selected_log_prob1[:, 0])

        if self.args.network_type == 'rnn':
            dag = _construct_dags_rnn(probs,
                                   _link_probs,
                                   self.func_names,
                                   self.args.num_blocks)

        if self.args.network_type == 'cnn':
            dag,Flag = _construct_dags_cnn(probs,
                                   probs1,
                                   self.func_names,
                                   self.args.num_blocks)

        if save_dir is not None:
            utils.draw_network(dag, os.path.join(save_dir, f'graph{idx}.png'))

        if with_details:
            return dag, torch.cat(log_probs), torch.cat(entropies), torch.cat(log_probs1), torch.cat(entropies1),Flag

        return dag

    def init_hidden(self, batch_size):
        zeros = torch.zeros(batch_size, self.args.controller_hid)
        return (utils.get_variable(zeros, self.args.cuda, requires_grad=False),
                utils.get_variable(zeros.clone(), self.args.cuda, requires_grad=False))
