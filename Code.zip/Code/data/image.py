import torch
import sys
import os
import numpy as np
from torchvision import datasets, transforms
from torch.utils.data.dataset import Subset
from torch.utils.data import DataLoader

class Cutout(object):
    """Randomly blurs patches of an image.
    Derived from https://github.com/uoguelph-mlrg/Cutout

    Args:
        n_holes(int): Number of patches to cut out of each image
        length(int): The length(px) of each square patch
        tensor_format(str): 'CHW' or 'HWC' (case insensitve) where C=Channels, H=Height, W=Width.
    """

    def __init__(self, n_holes, length, p=0.5, tensor_format='CHW'):
        """Initialize the cutout class.

        Args:
            n_holes(int): Number of patches to cut out of each image
            length(int): The length(px) of each square patch
            tensor_format(str): 'CHW' or 'HWC' (case insensitve) where C=Channels, H=Height, W=Width.
        """
        assert type(n_holes) == int, "Wrong dtype of n_holes, required integer, received {}".format(type(n_holes))
        assert type(length) == int, "Wrong dtype of length, required integer, received {}".format(type(length))
        assert p > 0 and p < 1, "Range of p in (0, 1), received {}".format(p)
        self.n_holes = n_holes
        self.length = length
        self.p = p
        if tensor_format.upper() in ['CHW', 'HWC']:
            self.tensor_format = tensor_format.upper()
        else:
            assert False, "{} tensor format not implemented".format(self.tensor_format)

    def __call__(self, image):
        """Override the call function to randomly apply CutOut in any image

        Args:
            image(Tensor): Tensor image of (C, H, W).
        Returns:
            Tensor: Image with n_holes of dimension length x length cutout of the original image.
        """
        if np.random.rand() < self.p:
            if self.tensor_format == 'CHW':
                h = image.size(1)
                w = image.size(2)
            elif self.tensor_format == 'HWC':
                h = image.size(0)
                w = image.size(1)

            mask = np.ones((h, w), np.float32)

            for n in range(self.n_holes):
                y = np.random.randint(h)
                x = np.random.randint(w)

                y1 = np.clip(y - self.length, 0, h)
                y2 = np.clip(y + self.length, 0, h)
                x1 = np.clip(x - self.length, 0, w)
                x2 = np.clip(x + self.length, 0, w)

                mask[y1: y2, x1: x2] = 0.

                mask = torch.from_numpy(mask)
                mask = mask.expand_as(image)
                image = image * mask

            mask.expand_as(image)
            image = image * mask

        return image


class AverageMeter(object):
    """General class to compute and store average and current values.
    """

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        """
        Update the meter's metrics for val
        """
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


class Logger(object):
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, 'w')

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()

    def flush(self):
        # this flush method is needed for python 3 compatibility.
        # this handles the flush command by doing nothing.
        # you might want to specify some extra behavior here.
        pass


supported_datasets = ['CIFAR10', 'CIFAR100', 'OTHER']


def load_datasets(args, dataset='CIFAR10',
                  train_dataset=None, test_dataset=None, valid_dataset=None,
                  train_indices=None, valid_indices=None):
    """ Loads dataset from path using PyTorch data loaders
    """

    path = args.data_path
    if not os.path.isdir(args.data_path):
        os.mkdir(args.data_path)

    assert args.data_path is not None, "None path received. Please specify path"
    assert dataset in supported_datasets, "dataset {} not in {}".format(dataset, *supported_datasets)
    if dataset == 'OTHER':
        assert train_dataset is not None, "Dataset specified other but empty train_dataset received"
        assert test_dataset is not None, "Dataset specified other but empty test_dataset received"
        assert valid_dataset is not None, "Dataset specified other but empty valid_dataset received"
        assert train_indices is not None, "Dataset specified other but empty train_indices received"
        assert valid_indices is not None, "Dataset specified other but empty valid_indices received"

    normalize = transforms.Normalize(mean=[x / 255.0 for x in [125.3, 123.0, 113.9]],
                                     std=[x / 255.0 for x in [63.0, 62.1, 66.7]])

    train_transform = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize
    ])

    if args.cutout > 0:
        train_transform.transforms.append(Cutout(n_holes=1, length=args.cutout))
    else:
        assert False, "Wrong cutout length specified. Length > 0, received {}".format(args.cutout)

    valid_transform = transforms.Compose([
        transforms.RandomCrop(32, padding=4),
        transforms.RandomHorizontalFlip(),
        transforms.ToTensor(),
        normalize
    ])

    test_transform = transforms.Compose([
        transforms.ToTensor(),
        normalize
    ])

    print(dataset)
    if dataset == 'CIFAR10':
        train_dataset = datasets.CIFAR10(root=path,
                                         train=True,
                                         transform=train_transform,
                                         download=True)

        test_dataset = datasets.CIFAR10(root=path,
                                        train=False,
                                        transform=test_transform,
                                        download=True)

        valid_dataset = datasets.CIFAR10(root=path,
                                         train=False,
                                         transform=valid_transform,
                                         download=True)

    elif dataset == 'CIFAR100':
        train_dataset = datasets.CIFAR100(root=path,
                                          train=True,
                                          transform=train_transform,
                                          download=True)

        test_dataset = datasets.CIFAR100(root=path,
                                         train=False,
                                         transform=test_transform,
                                         download=True)

        valid_dataset = datasets.CIFAR100(root=path,
                                          train=False,
                                          transform=valid_transform,
                                          download=True)

    data_loaders = dict()
    data_loaders['train_subset'] = DataLoader(dataset=train_dataset,
                                              batch_size=args.batch_size,
                                              shuffle=True,
                                              pin_memory=True,
                                              num_workers=args.num_workers)

    data_loaders['valid_subset'] = DataLoader(dataset=valid_dataset,
                                              batch_size=args.batch_size,
                                              shuffle=True,
                                              pin_memory=True,
                                              num_workers=args.num_workers)

    data_loaders['train_dataset'] = DataLoader(dataset=train_dataset,
                                               batch_size=args.batch_size,
                                               shuffle=True,
                                               pin_memory=True,
                                               num_workers=args.num_workers)

    data_loaders['test_dataset'] = DataLoader(dataset=test_dataset,
                                              batch_size=args.batch_size,
                                              shuffle=True,
                                              pin_memory=True,
                                              num_workers=args.num_workers)

    return data_loaders