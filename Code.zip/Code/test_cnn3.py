import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision.datasets import MNIST, CIFAR10, CIFAR100
from torchvision.transforms import ToTensor
from torchsummary import summary
from torchstat import stat
class Cell(nn.Module):
    """Implement one ENAS cell (or node), each cell can have 5 different operations:
       avg_pool, max_pool, 3*3 conv, 5*5 conv, identity.
    """

    def __init__(self, in_channels, out_channels):
        super(Cell, self).__init__()
        self.conv5_1 = nn.Conv2d(in_channels,out_channels,kernel_size=5,stride=1,padding=2) #使用5*5卷积核，padding=2，保持输入输出尺寸一致
        self.conv5_2 = nn.Conv2d(in_channels, out_channels, kernel_size=5, stride=1,padding=2)  # 使用5*5卷积核，padding=2，保持输入输出尺寸一致
        self.conv5_3 = nn.Conv2d(in_channels, out_channels, kernel_size=5, stride=1,padding=2)  # 使用5*5卷积核，padding=2，保持输入输出尺寸一致
        self.conv5_4 = nn.Conv2d(in_channels, out_channels, kernel_size=5, stride=1,padding=2)  # 使用5*5卷积核，padding=2，保持输入输出尺寸一致
        self.conv5_5 = nn.Conv2d(in_channels, out_channels, kernel_size=5, stride=1,padding=2)  # 使用5*5卷积核，padding=2，保持输入输出尺寸一致
        self.conv5_6 = nn.Conv2d(in_channels, out_channels, kernel_size=5, stride=1,padding=2)  # 使用5*5卷积核，padding=2，保持输入输出尺寸一致
        self.conv5_7 = nn.Conv2d(in_channels, out_channels, kernel_size=5, stride=1,padding=2)  # 使用5*5卷积核，padding=2，保持输入输出尺寸一致
        self.conv5_8 = nn.Conv2d(in_channels, out_channels, kernel_size=5, stride=1,padding=2)  # 使用5*5卷积核，padding=2，保持输入输出尺寸一致
        self.max_pool = nn.MaxPool2d(kernel_size=3, stride=1, padding=1, ceil_mode=True)

        self.conv5_1 = self.conv5_1.to("cuda")
        self.conv5_2 = self.conv5_2.to("cuda")
        self.conv5_3 = self.conv5_3.to("cuda")
        self.conv5_4 = self.conv5_4.to("cuda")
        self.conv5_5 = self.conv5_5.to("cuda")
        self.conv5_6= self.conv5_6.to("cuda")
        self.conv5_7 = self.conv5_7.to("cuda")
        self.conv5_8 = self.conv5_8.to("cuda")
        self.max_pool = self.max_pool.to("cuda")

    def forward(self, x1, x2):
        """
        Args:
            x: input from previous cell.
            op: integer, indicate which operation to use.
        """
        #
        # add0 = self.max_pool(x1)
        # add1 = self.conv5_1(add0)+self.max_pool(x1)
        # add2 = self.conv5_2(x1)+self.max_pool(add0)
        # add3 = self.conv5_3(add2)+self.max_pool(x1)
        # add4 = self.conv5_4(add1)+self.max_pool(add1)
        # add5 = self.conv5_5(add4)+self.max_pool(add3)
        # add9 = self.conv5_6(add5)+self.max_pool(add4)
        # add10 = self.conv5_7(x2)+self.max_pool(add9)
        # add11 = self.conv5_8(add2) + self.max_pool(add10)
        # x = torch.softmax(add11,dim=0)


        #两种网络
        add0 = self.max_pool(x2)+self.conv5_1(x2)
        add1 = self.max_pool(x1)+self.conv5_2(add0)
        add2 = self.max_pool(add1)+self.conv5_3(x1)
        add4= self.max_pool(add2)+self.conv5_4(add2)
        add8 = self.max_pool(add4)+self.conv5_5(add0)
        x = self.max_pool(add2)+self.conv5_6(add8)
        # x = torch.softmax(add11,dim=0)
        return x


class SimpleCNN(nn.Module):
    def __init__(self, num_classes,channels,features):
        super(SimpleCNN, self).__init__()
        self.channels = channels
        self.classifier = nn.Sequential(
            nn.Linear(2048, num_classes)
        )
        self.stem_conv = []
        self.nodes = []
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(64, track_running_stats=False)).cuda())
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(128, track_running_stats=False)).cuda())
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(256, track_running_stats=False)).cuda())
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(256, 512, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(512, track_running_stats=False)).cuda())

        self.nodes.append(Cell(64, 64))
        self.nodes.append(Cell(128, 128))
        self.nodes.append(Cell(256, 256))
        self.nodes.append(Cell(512, 512))
        self.global_max_pool = nn.MaxPool2d(kernel_size=2, stride=2)


    def forward(self, x):
        x0 = self.stem_conv[0](x)
        x1 = self.nodes[0](x0,x0)

        x0 = self.global_max_pool(x0)
        x1 = self.global_max_pool(x1)

        x01 = self.stem_conv[1](x0)
        x11 = self.stem_conv[1](x1)
        x2 = self.nodes[1](x01, x11)

        x11 = self.global_max_pool(x11)
        x2 = self.global_max_pool(x2)

        x11 = self.stem_conv[2](x11)
        x21 = self.stem_conv[2](x2)
        x3 = self.nodes[2](x11, x21)

        x21 = self.global_max_pool(x21)
        x3 = self.global_max_pool(x3)

        x21 = self.stem_conv[3](x21)
        x31 = self.stem_conv[3](x3)
        x = self.nodes[3](x21, x31)

        x = self.global_max_pool(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x


def train(model, train_loader, criterion, optimizer, device):
    model.train()
    cur = 0
    num = 0
    starter, ender = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        starter.record()
        outputs = model(images)
        ender.record()
        torch.cuda.synchronize()
        cur += starter.elapsed_time(ender)
        num +=1
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
    print(cur/num)

def test(model, test_loader, criterion, device):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
    accuracy = 100 * correct / total
    return accuracy

# 选择数据集
# dataset_name = input("请选择数据集（输入 'MNIST' 或 'CIFAR10'）: ")
dataset_name  = 'CIFAR10'
if dataset_name == 'MNIST':
    train_dataset = MNIST(root='data', train=True, transform=ToTensor(), download=True)
    test_dataset = MNIST(root='data', train=False, transform=ToTensor())
    channels = 1
    num_classes = 10
    features = 1568
elif dataset_name == 'CIFAR10':
    train_dataset = CIFAR10(root='data', train=True, transform=ToTensor(), download=True)
    test_dataset = CIFAR10(root='data', train=False, transform=ToTensor())
    channels = 3
    num_classes = 10
    features = 2048
elif dataset_name == "CIFAR100":
    train_dataset = CIFAR100(root='data', train=True, transform=ToTensor(), download=True)
    test_dataset = CIFAR100(root='data', train=False, transform=ToTensor())
    channels = 3
    num_classes = 100
    features = 2048
else:
    print("无效的数据集选择。")
    exit()

# 设定训练参数
batch_size = 64
learning_rate = 0.001
num_epochs = 10

# 加载数据
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# 初始化模型和优化器
model = SimpleCNN(num_classes, channels,features)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# print("device",device)
# stat(model, (3, 32, 32))
model = model.cuda()


# summary(model, (3, 32, 32))
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate)
# print(device)
# 进行训练和测试
# stat(model, (3, 32, 32))
for epoch in range(num_epochs):
    train(model, train_loader, criterion, optimizer, device)
    accuracy = test(model, test_loader, criterion, device)
    print(f"Epoch [{epoch+1}/{num_epochs}], Accuracy: {accuracy:.2f}%")
