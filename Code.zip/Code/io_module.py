import os

os.environ["DGLBACKEND"] = "pytorch"

os.environ['CUDA_LAUNCH_BLOCKING'] = '1'

import torch
import torch.nn as nn
import collections

class io_analyze(nn.Module):
    def __init__(self, args):
        super(io_analyze, self).__init__()
        self.args = args
        self.vol_limit = self.args.vol_limit
        self.node_num = self.args.num_blocks
        self.times=self.args.times

    def dag_convert(self, dag):
        self.dag = dag
        self.prev_node_id = []
        self.prev_node_op = []
        for node_id in range(self.node_num+3):
            self.prev_node_id.append([])
            self.prev_node_op.append([])

        for node_id in range(-2,self.node_num+1,1):
            nodes = dag[node_id]
            for next_node in nodes:
                self.prev_node_id[next_node.id+2].append(node_id)
                self.prev_node_op[next_node.id+2].append(next_node.name)

    def _dag_to_io_lower_bound(self, dag, node_num, input_t, type):
        self.dag_convert(dag)
        io_all = 0
        for i in range(self.times):
            data_info = collections.defaultdict(list)
            data_now = collections.defaultdict(list)
            vol = int(torch.randn(1)*self.vol_limit)
            io_ops = 0
            legal_node = [-3]
            data_info[-3] = vol
            data_now[-3] = vol


            for node_id in range(-2,node_num+1):
                if len(self.prev_node_id[node_id+2])==0 and node_id!=-2 and node_id!=-1:
                    continue
                if len(dag[node_id])==0 and node_id!=node_num:
                    continue
                legal_node.append(node_id)
                for index in range(len(self.prev_node_id[node_id+2])):
                    last_node = self.prev_node_id[node_id+2][index]

                    if data_now[last_node] < data_info[last_node]:
                        if data_info[last_node] - data_now[last_node] <= self.vol_limit - vol:
                            io_ops += data_info[last_node] - data_now[last_node]
                            clear_data = 0
                            vol += data_info[last_node] - data_now[last_node]
                        else:
                            io_ops += data_info[last_node] - data_now[last_node]
                            clear_data = (data_info[last_node] - data_now[last_node]) + vol - self.vol_limit
                            vol = self.vol_limit
                        for i in range(-3,node_id,1):
                            if i not in legal_node:
                                continue
                            if i == last_node:
                                continue
                            elif clear_data == 0:
                                break
                            else:
                                if data_now[i] >= clear_data:
                                    data_now[i] -= clear_data
                                    io_ops += clear_data
                                    break
                                else:
                                    data_now[i] = 0
                                    clear_data -= data_now[i]
                                    io_ops += data_now[i]

                data_info[node_id] = input_t
                if self.vol_limit - vol < data_info[node_id]:
                    io_ops += data_info[node_id] + vol - self.vol_limit
                    clear_data = data_info[node_id] + vol - self.vol_limit
                    vol = self.vol_limit
                    data_now[node_id] = data_info[node_id]
                    for i in range(-3,node_id+1,1):
                        if i not in legal_node:
                            continue
                        if clear_data == 0:
                            break
                        else:
                            if data_now[i] >= clear_data:
                                data_now[i] -= clear_data
                                break
                            else:
                                data_now[i] = 0
                                clear_data -= data_now[i]
                else:
                    data_now[node_id] = data_info[node_id]
                    vol = vol + data_now[node_id]
            io_all += io_ops
        #step3: calculate the I/O lower bound
        return io_all/self.times