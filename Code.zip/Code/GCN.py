import os

os.environ["DGLBACKEND"] = "pytorch"

os.environ['CUDA_LAUNCH_BLOCKING'] = '1'
import dgl
import dgl.data
import torch
import math
import torch.nn as nn
import torch.nn.functional as F

from dgl.nn import GraphConv

class GCN(nn.Module):
    def __init__(self, in_feats, h_feats, num_classes, node_num, network_type):
        super(GCN, self).__init__()
        self.conv1 = GraphConv(in_feats, h_feats)
        self.conv4 = GraphConv(h_feats, h_feats)
        self.conv5 = GraphConv(h_feats, h_feats)
        self.type = network_type
        if network_type=='rnn':
            self.conv2 = GraphConv(h_feats, num_classes)
            self.conv3 = GraphConv(h_feats, node_num-1)
        if network_type=='cnn':
            self.conv6 = GraphConv(h_feats, h_feats)
            self.conv2 = GraphConv(h_feats, num_classes*num_classes)
            self.conv7 = GraphConv(h_feats, h_feats)
            self.conv3 = GraphConv(h_feats, (node_num+1)*(node_num+1))

    def forward(self, g, in_feat):
        h = self.conv1(g, in_feat)
        h2 = F.relu(h)
        h2 = self.conv5(g, h2)
        h2 = F.relu(h2)
        if self.type=='rnn':
            h = self.conv2(g, h2)
            h2 = F.sigmoid(self.conv3(g, h2))
        else:
            h2 = self.conv6(g, h2)
            h2 = F.relu(h2)
            h = self.conv2(g, h2)
            h2 = self.conv7(g, h2)
            h2 = F.relu(h2)
            h2 = self.conv3(g, h2)
        return h, h2

