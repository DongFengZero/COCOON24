import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision.datasets import MNIST, CIFAR10, CIFAR100
from torchvision.transforms import ToTensor
from torchsummary import summary
from torchstat import stat
class Cell(nn.Module):
    """Implement one ENAS cell (or node), each cell can have 5 different operations:
       avg_pool, max_pool, 3*3 conv, 5*5 conv, identity.
    """

    def __init__(self, in_channels, out_channels):
        super(Cell, self).__init__()

        self.in_channels, self.out_channels = in_channels, out_channels

        self.conv1 = nn.Sequential(
            nn.Conv2d(self.in_channels, self.out_channels, kernel_size=1, bias=False).cuda(),
            nn.BatchNorm2d(self.out_channels, track_running_stats=False).cuda(),
            nn.ReLU())
        self.pool = torch.nn.AvgPool2d(kernel_size=3, stride=1, padding=1)

        self.conv2 = nn.Sequential(
            nn.Conv2d(self.in_channels, self.out_channels, kernel_size=1, bias=False).cuda(),
            nn.BatchNorm2d(self.out_channels, track_running_stats=False).cuda(),
            nn.ReLU())
        self.pool2 = torch.nn.AvgPool2d(kernel_size=3, stride=1, padding=1)

        self.conv3 = nn.Sequential(
            nn.Conv2d(self.in_channels, self.out_channels, kernel_size=1, bias=False).cuda(),
            nn.BatchNorm2d(self.out_channels, track_running_stats=False).cuda(),
            nn.ReLU())
        self.pool3 = torch.nn.AvgPool2d(kernel_size=3, stride=1, padding=1)

        self.inp_conv1 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False).cuda(),
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())

        kernel_size = 3
        padding = (kernel_size - 1) // 2  # keep the size unchanged
        self.depthwise = nn.Conv2d(in_channels, in_channels,
                                   kernel_size=kernel_size,
                                   padding=padding,
                                   groups=in_channels,
                                   bias=True).cuda()
        self.pointwise = nn.Conv2d(in_channels, out_channels,
                                   kernel_size=1, bias=True).cuda()
        self.relu_bn = nn.Sequential(
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())

        self.inp_conv2 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False).cuda(),
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())

        padding = (kernel_size - 1) // 2  # keep the size unchanged
        self.depthwise2 = nn.Conv2d(in_channels, in_channels,
                                   kernel_size=kernel_size,
                                   padding=padding,
                                   groups=in_channels,
                                   bias=True).cuda()
        self.pointwise2 = nn.Conv2d(in_channels, out_channels,
                                   kernel_size=1, bias=True).cuda()
        self.relu_bn2 = nn.Sequential(
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())

        self.inp_conv3 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False).cuda(),
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())

        padding = (kernel_size - 1) // 2  # keep the size unchanged
        self.depthwise3 = nn.Conv2d(in_channels, in_channels,
                                    kernel_size=kernel_size,
                                    padding=padding,
                                    groups=in_channels,
                                    bias=True).cuda()
        self.pointwise3 = nn.Conv2d(in_channels, out_channels,
                                    kernel_size=1, bias=True).cuda()
        self.relu_bn3 = nn.Sequential(
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())

    def forward(self, x1, x2):
        """
        Args:
            x: input from previous cell.
            op: integer, indicate which operation to use.
        """
        out11 = self.pool(x1)

        out13 = self.pointwise(self.depthwise(x2))
        out13 = out13 + x2
        out13 = self.relu_bn(out13)

        out1 = out13 + out11

        out11 = self.pool(x1)

        out13 = self.pointwise2(self.depthwise2(x2))
        out13 = out13 + x2
        out13 = self.relu_bn(out13)

        out2 = out13 + out11

        out11 = self.pool(out1)

        out13 = self.pointwise3(self.depthwise3(out2))
        out13 = out13 + out2
        out13 = self.relu_bn(out13)

        out3 = out13 + out11

        return out3


class SimpleCNN(nn.Module):
    def __init__(self, num_classes,channels,features):
        super(SimpleCNN, self).__init__()
        self.channels = channels
        self.classifier = nn.Sequential(
            nn.Linear(2048, num_classes)
        )
        self.stem_conv = []
        self.nodes = []
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(64, track_running_stats=False)).cuda())
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(128, track_running_stats=False)).cuda())
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(256, track_running_stats=False)).cuda())
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(256, 512, kernel_size=3, padding=1, bias=False),
            nn.BatchNorm2d(512, track_running_stats=False)).cuda())
        self.nodes.append(Cell(64, 64))
        self.nodes.append(Cell(128, 128))
        self.nodes.append(Cell(256, 256))
        self.nodes.append(Cell(512, 512))
        self.global_max_pool = nn.MaxPool2d(kernel_size=2, stride=2)


    def forward(self, x):
        x0 = self.stem_conv[0](x)
        x1 = self.nodes[0](x0,x0)

        x0 = self.global_max_pool(x0)
        x1 = self.global_max_pool(x1)

        x01 = self.stem_conv[1](x0)
        x11 = self.stem_conv[1](x1)
        x2 = self.nodes[1](x01, x11)

        x11 = self.global_max_pool(x11)
        x2 = self.global_max_pool(x2)

        x11 = self.stem_conv[2](x11)
        x21 = self.stem_conv[2](x2)
        x3 = self.nodes[2](x11, x21)

        x21 = self.global_max_pool(x21)
        x3 = self.global_max_pool(x3)

        x21 = self.stem_conv[3](x21)
        x31 = self.stem_conv[3](x3)
        x = self.nodes[3](x21, x31)

        x = self.global_max_pool(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x


def train(model, train_loader, criterion, optimizer, device):
    model.train()
    cur = 0
    num = 0
    starter, ender = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    for images, labels in train_loader:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        starter.record()
        outputs = model(images)
        ender.record()
        torch.cuda.synchronize()
        cur += starter.elapsed_time(ender)
        num +=1
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
    print(cur/num)

def test(model, test_loader, criterion, device):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for images, labels in test_loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            _, predicted = torch.max(outputs.data, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
    accuracy = 100 * correct / total
    return accuracy

# 选择数据集
# dataset_name = input("请选择数据集（输入 'MNIST' 或 'CIFAR10'）: ")
dataset_name  = 'CIFAR10'
if dataset_name == 'MNIST':
    train_dataset = MNIST(root='data', train=True, transform=ToTensor(), download=True)
    test_dataset = MNIST(root='data', train=False, transform=ToTensor())
    channels = 1
    num_classes = 10
    features = 1568
elif dataset_name == 'CIFAR10':
    train_dataset = CIFAR10(root='data', train=True, transform=ToTensor(), download=True)
    test_dataset = CIFAR10(root='data', train=False, transform=ToTensor())
    channels = 3
    num_classes = 10
    features = 2048
elif dataset_name == "CIFAR100":
    train_dataset = CIFAR100(root='data', train=True, transform=ToTensor(), download=True)
    test_dataset = CIFAR100(root='data', train=False, transform=ToTensor())
    channels = 3
    num_classes = 100
    features = 2048
else:
    print("无效的数据集选择。")
    exit()

# 设定训练参数
batch_size = 64
learning_rate = 0.001
num_epochs = 10

# 加载数据
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# 初始化模型和优化器
model = SimpleCNN(num_classes, channels,features)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# stat(model.to('cpu'), (3, 32, 32))
model = model.cuda()


# summary(model, (3, 32, 32))
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate)
# print(device)
# 进行训练和测试
# stat(model.to(device), (3, 32, 32))
for epoch in range(num_epochs):
    train(model, train_loader, criterion, optimizer, device)
    accuracy = test(model, test_loader, criterion, device)
    print(f"Epoch [{epoch+1}/{num_epochs}], Accuracy: {accuracy:.2f}%")
