import torch
import torch.nn as nn
import torch.optim as optim
from torchvision import datasets,transforms
from torch.utils.data import DataLoader
from torchvision.datasets import MNIST, CIFAR10, CIFAR100
from torchvision.transforms import ToTensor
from torch.utils.data.dataset import Subset
from torchsummary import summary
from torchstat import stat
class AverageMeter(object):
    """General class to compute and store average and current values.
    """

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        """
        Update the meter's metrics for val
        """
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

class ENASCell(nn.Module):
    """Implement one ENAS cell (or node), each cell can have 5 different operations:
       avg_pool, max_pool, 3*3 conv, 5*5 conv, identity.
    """

    def __init__(self, in_channels, out_channels):
        super(ENASCell, self).__init__()

        self.in_channels, self.out_channels = in_channels, out_channels

        kernel_size = 5
        padding = (kernel_size - 1) // 2  # keep the size unchanged
        self.depthwise = nn.Conv2d(in_channels, in_channels,
                                   kernel_size=kernel_size,
                                   padding=padding,
                                   groups=in_channels,
                                   bias=True).cuda()
        self.pointwise = nn.Conv2d(in_channels, out_channels,
                                   kernel_size=1, bias=True).cuda()
        self.relu_bn = nn.Sequential(
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())

        self.depthwise2 = nn.Conv2d(in_channels, in_channels,
                                    kernel_size=kernel_size,
                                    padding=padding,
                                    groups=in_channels,
                                    bias=True).cuda()
        self.pointwise2 = nn.Conv2d(in_channels, out_channels,
                                    kernel_size=1, bias=True).cuda()
        self.relu_bn2 = nn.Sequential(
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())


        self.depthwise3 = nn.Conv2d(in_channels, in_channels,
                                    kernel_size=kernel_size,
                                    padding=padding,
                                    groups=in_channels,
                                    bias=True).cuda()
        self.pointwise3 = nn.Conv2d(in_channels, out_channels,
                                    kernel_size=1, bias=True).cuda()
        self.relu_bn3 = nn.Sequential(
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())

        self.depthwise4 = nn.Conv2d(in_channels, in_channels,
                                    kernel_size=kernel_size,
                                    padding=padding,
                                    groups=in_channels,
                                    bias=True).cuda()
        self.pointwise4 = nn.Conv2d(in_channels, out_channels,
                                    kernel_size=1, bias=True).cuda()
        self.relu_bn4 = nn.Sequential(
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())

        self.depthwise5 = nn.Conv2d(in_channels, in_channels,
                                    kernel_size=kernel_size,
                                    padding=padding,
                                    groups=in_channels,
                                    bias=True).cuda()
        self.pointwise5 = nn.Conv2d(in_channels, out_channels,
                                    kernel_size=1, bias=True).cuda()
        self.relu_bn5 = nn.Sequential(
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())

        self.depthwise6 = nn.Conv2d(in_channels, in_channels,
                                    kernel_size=kernel_size,
                                    padding=padding,
                                    groups=in_channels,
                                    bias=True).cuda()
        self.pointwise6 = nn.Conv2d(in_channels, out_channels,
                                    kernel_size=1, bias=True).cuda()
        self.relu_bn6 = nn.Sequential(
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())


        self.depthwise8 = nn.Conv2d(in_channels, in_channels,
                                    kernel_size=kernel_size,
                                    padding=padding,
                                    groups=in_channels,
                                    bias=True).cuda()
        self.pointwise8 = nn.Conv2d(in_channels, out_channels,
                                    kernel_size=1, bias=True).cuda()
        self.relu_bn8 = nn.Sequential(
            nn.BatchNorm2d(out_channels, track_running_stats=False).cuda(),
            nn.ReLU())

    def forward(self, x1, x2):
        """
        Args:
            x: input from previous cell.
            op: integer, indicate which operation to use.
        """

        out01 = self.pointwise4(self.depthwise4(x1))
        out01 = out01 + x1
        out01 = self.relu_bn4(out01)
        out02 = self.pointwise(self.depthwise(x2))
        out02 = out02 + x2
        out02 = self.relu_bn(out02)
        out0 = out01 + out02

        out11 = self.pointwise5(self.depthwise5(out0))
        out11 = out11 + out0
        out11 = self.relu_bn5(out11)
        out12 = self.pointwise2(self.depthwise2(x1))
        out12 = out12 + x1
        out12 = self.relu_bn2(out12)
        out1 = out11 + out12

        out21 = self.pointwise8(self.depthwise8(out1))
        out21 = out21 + out1
        out21 = self.relu_bn8(out21)
        out22 = self.pointwise4(self.depthwise3(x1))
        out22 = out22 + x1
        out22 = self.relu_bn4(out22)
        out2 = out21 + out22

        out111 = self.pointwise6(self.depthwise6(x2))
        out111 = out111 + x2
        out111 = self.relu_bn6(out111)
        out112 = self.pointwise3(self.depthwise3(out2))
        out112 = out112 + out2
        out112 = self.relu_bn3(out112)
        out11 = out111 + out112

        return out11


class SimpleCNN(nn.Module):
    def __init__(self, num_classes,channels,features):
        super(SimpleCNN, self).__init__()
        self.channels = channels
        self.classifier = nn.Sequential(
            nn.Linear(2048, num_classes, bias=False)
        )
        self.stem_conv = []
        self.nodes = nn.ModuleList()
        Cell = ENASCell
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(3, 64, kernel_size=3, padding=1, bias=False).cuda(),
            nn.BatchNorm2d(64, track_running_stats=False)).cuda())
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(64, 128, kernel_size=3, padding=1, bias=False).cuda(),
            nn.BatchNorm2d(128, track_running_stats=False)).cuda())
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(128, 256, kernel_size=3, padding=1, bias=False).cuda(),
            nn.BatchNorm2d(256, track_running_stats=False)).cuda())
        self.stem_conv.append(nn.Sequential(
            nn.Conv2d(256, 512, kernel_size=3, padding=1, bias=False).cuda(),
            nn.BatchNorm2d(512, track_running_stats=False)).cuda())
        self.nodes.append(Cell(64, 64))
        self.nodes.append(Cell(128, 128))
        self.nodes.append(Cell(256, 256))
        self.nodes.append(Cell(512, 512))
        self.global_max_pool = nn.MaxPool2d(kernel_size=2, stride=2)


    def forward(self, x):
        x0 = self.stem_conv[0](x)
        x1 = self.nodes[0](x0,x0)

        x0 = self.global_max_pool(x0)
        x1 = self.global_max_pool(x1)

        x01 = self.stem_conv[1](x0)
        x11 = self.stem_conv[1](x1)
        x2 = self.nodes[1](x01, x11)

        x11 = self.global_max_pool(x11)
        x2 = self.global_max_pool(x2)

        x11 = self.stem_conv[2](x11)
        x21 = self.stem_conv[2](x2)
        x3 = self.nodes[2](x11, x21)

        x21 = self.global_max_pool(x21)
        x3 = self.global_max_pool(x3)

        x21 = self.stem_conv[3](x21)
        x31 = self.stem_conv[3](x3)
        x = self.nodes[3](x21, x31)

        x = self.global_max_pool(x)
        x = x.view(x.size(0), -1)
        x = self.classifier(x)
        return x


def train(model, train_loader, criterion, optimizer, device):
    model.train()
    cur = 0
    num = 0
    starter, ender = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
    loss1 =0
    time = 0
    for j, (images, labels) in enumerate(train_loader):
        images, labels = images.to(device), labels.to(device)
        starter.record()
        model.zero_grad()
        #images.requires_grad = True
        outputs = model(images)
        ender.record()
        torch.cuda.synchronize()
        cur += starter.elapsed_time(ender)
        num +=1
        loss = torch.nn.CrossEntropyLoss()(outputs, labels)
        loss1+=loss
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
    return cur/num,loss1

def test(model, test_loader, criterion, device):
    model.eval()
    correct = 0
    total = 0
    train_acc_meter = AverageMeter()
    with torch.no_grad():
        for j, (images, labels) in enumerate(test_loader):
            images, labels = images.to(device), labels.to(device)
            pred = model(images)
            _, predicted = torch.max(pred, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
            # train_acc = torch.mean((torch.max(pred,1)[1]==labels).type(torch.float))
            # train_acc_meter.update(train_acc.item())
    #
    accuracy = 100 * correct / total
    return accuracy
    # return train_acc_meter.val

normalize = transforms.Normalize(mean=[x / 255.0 for x in [125.3, 123.0, 113.9]],
                                     std=[x / 255.0 for x in [63.0, 62.1, 66.7]])

train_transform = transforms.Compose([
    transforms.RandomCrop(32, padding=4),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    normalize
])

# train_transform.transforms.append(Cutout(n_holes=1, length=1))


valid_transform = transforms.Compose([
    transforms.RandomCrop(32, padding=4),
    transforms.RandomHorizontalFlip(),
    transforms.ToTensor(),
    normalize
])

test_transform = transforms.Compose([
    transforms.ToTensor(),
    normalize
])

dataset_name  = 'CIFAR10'
path = 'data'
if dataset_name == 'CIFAR10':
    channels = 3
    num_classes = 10
    features = 2048
    train_dataset = datasets.CIFAR10(root=path,
                                     train=True,
                                     transform=train_transform,
                                     download=True)

    test_dataset = datasets.CIFAR10(root=path,
                                    train=False,
                                    transform=test_transform,
                                    download=True)

    valid_dataset = datasets.CIFAR10(root=path,
                                     train=False,
                                     transform=valid_transform,
                                     download=True)

    # train_indices = list(range(0, 45000))
    # valid_indices = list(range(45000, 50000))
    # train_subset = Subset(train_dataset, train_indices)
    # valid_subset = Subset(valid_dataset, valid_indices)

elif dataset_name == 'CIFAR100':
    channels = 3
    num_classes = 100
    features = 2048
    train_dataset = datasets.CIFAR100(root=path,
                                      train=True,
                                      transform=train_transform,
                                      download=True)

    test_dataset = datasets.CIFAR100(root=path,
                                     train=False,
                                     transform=test_transform,
                                     download=True)

    valid_dataset = datasets.CIFAR100(root=path,
                                      train=False,
                                      transform=valid_transform,
                                      download=True)

    # train_indices = list(range(0, 45000))
    # valid_indices = list(range(45000, 50000))
    # train_subset = Subset(train_dataset, train_indices)
    # valid_subset = Subset(valid_dataset, valid_indices)

batch_size = 64
num_workers = 2
data_loaders = dict()
data_loaders['train_subset'] = DataLoader(dataset=train_dataset,
                                          batch_size=batch_size,
                                          shuffle=True,
                                          pin_memory=True,
                                          num_workers=num_workers)

data_loaders['valid_subset'] = DataLoader(dataset=test_dataset,
                                          batch_size=batch_size,
                                          shuffle=True,
                                          pin_memory=True,
                                          num_workers=num_workers)

data_loaders['train_dataset'] = DataLoader(dataset=train_dataset,
                                           batch_size=batch_size,
                                           shuffle=True,
                                           pin_memory=True,
                                           num_workers=num_workers)

data_loaders['test_dataset'] = DataLoader(dataset=test_dataset,
                                          batch_size=batch_size,
                                          shuffle=True,
                                          pin_memory=True,
                                          num_workers=num_workers)

train_loader = data_loaders['train_subset']
test_loader = data_loaders['valid_subset']
# 选择数据集
# dataset_name = input("请选择数据集（输入 'MNIST' 或 'CIFAR10'）: ")
# if dataset_name == 'MNIST':
#     train_dataset = MNIST(root='data', train=True, transform=ToTensor(), download=True)
#     test_dataset = MNIST(root='data', train=False, transform=ToTensor())
#     channels = 1
#     num_classes = 10
#     features = 1568
# elif dataset_name == 'CIFAR10':
#     train_dataset = CIFAR10(root='data', train=True, transform=ToTensor(), download=True)
#     test_dataset = CIFAR10(root='data', train=False, transform=ToTensor())
#     channels = 3
#     num_classes = 10
#     features = 2048
# elif dataset_name == "CIFAR100":
#     train_dataset = CIFAR100(root='data', train=True, transform=ToTensor(), download=True)
#     test_dataset = CIFAR100(root='data', train=False, transform=ToTensor())
#     channels = 3
#     num_classes = 100
#     features = 2048
# else:
#     print("无效的数据集选择。")
#     exit()

# 设定训练参数
learning_rate = 3.5e-4
num_epochs = 100
# num_classes = 10
# 加载数据
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

# 初始化模型和优化器
model = SimpleCNN(num_classes, channels,features)

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
# stat(model.to('cpu'), (3, 32, 32))
model = model.cuda()


# summary(model, (3, 32, 32))
criterion = nn.CrossEntropyLoss()
optimizer = optim.Adam(model.parameters(), lr=learning_rate)
# print(device)
# 进行训练和测试
# stat(model.to(device), (3, 32, 32))
acc = []
loss = []
time = 0
for epoch in range(num_epochs):
    time1,loss1 = train(model, train_loader, criterion, optimizer, device)
    accuracy = test(model, test_loader, criterion, device)
    acc.append(accuracy)
    loss.append(loss1)
    time = (time*epoch+time1)/(epoch+1)
    print(f"Epoch [{epoch+1}/{num_epochs}], Accuracy: {accuracy:.2f}, Time: {time1:.2f}, ")
print(acc)
print(loss)
print(time)